--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2
-- Dumped by pg_dump version 16.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "precio-por-rep-bd";
--
-- Name: precio-por-rep-bd; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "precio-por-rep-bd" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Spanish_Chile.1252';


ALTER DATABASE "precio-por-rep-bd" OWNER TO postgres;

\connect -reuse-previous=on "dbname='precio-por-rep-bd'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: precio_reparacion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.precio_reparacion (
    id bigint NOT NULL,
    nombre_de_la_rep character varying(255),
    precio_diesel integer NOT NULL,
    precio_electrico integer NOT NULL,
    precio_gasolina integer NOT NULL,
    precio_hibrido integer NOT NULL
);


ALTER TABLE public.precio_reparacion OWNER TO postgres;

--
-- Name: precio_reparacion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.precio_reparacion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.precio_reparacion_id_seq OWNER TO postgres;

--
-- Name: precio_reparacion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.precio_reparacion_id_seq OWNED BY public.precio_reparacion.id;


--
-- Name: precio_reparacion id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.precio_reparacion ALTER COLUMN id SET DEFAULT nextval('public.precio_reparacion_id_seq'::regclass);


--
-- Data for Name: precio_reparacion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.precio_reparacion (id, nombre_de_la_rep, precio_diesel, precio_electrico, precio_gasolina, precio_hibrido) FROM stdin;
\.
COPY public.precio_reparacion (id, nombre_de_la_rep, precio_diesel, precio_electrico, precio_gasolina, precio_hibrido) FROM '$$PATH$$/4835.dat';

--
-- Name: precio_reparacion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.precio_reparacion_id_seq', 12, true);


--
-- Name: precio_reparacion precio_reparacion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.precio_reparacion
    ADD CONSTRAINT precio_reparacion_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

